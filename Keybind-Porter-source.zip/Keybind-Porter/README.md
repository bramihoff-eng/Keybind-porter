# Keybind Porter

A client-only Fabric mod that moves key bindings between Minecraft instances
using readable UTF-8 .txt profiles. Includes builds for Minecraft 1.21.11 and 26.3.

## Install

Use the JAR matching your Minecraft version, in that instance's mods folder:

- keybind-porter-1.0.0+1.21.11.jar: Minecraft 1.21.11, Java 21 or newer.
- keybind-porter-1.0.0+26.3.jar: Minecraft 26.3, Java 25 or newer.

Both need Fabric Loader 0.19.5 or newer. Fabric API and Mod Menu are not required.
Install only one version of Keybind Porter in each client instance. A server
installation is not needed.

## Export your keys

1. Open Options > Controls > Key Binds.
2. Click Export keys...
3. Keep the generated filename, or enter a filename/full path of your choice.
4. Click Export file. Open folder opens the instance's keybind-profiles directory.

A relative filename goes into keybind-profiles inside the Minecraft instance.
An absolute path can save elsewhere, including Downloads. Existing files are
not overwritten; choose a new name if the export filename already exists.

## Import into another version

1. Install that version's Keybind Porter JAR.
2. Copy your exported .txt file into the target instance's keybind-profiles directory.
3. Open Options > Controls > Key Binds > Import keys...
4. Select your file from the list, then click Import file.

You can also paste the full path of a file stored elsewhere. The path field
supports normal copy/paste. Previous/Next paginate longer profile lists;
Refresh updates the list after you copy a new file into the directory.

Import updates matching bindings immediately and saves Minecraft's options.
A before-import-*.txt backup of the previous keys is saved first. Import that
backup to undo a change. No backup can be written means no keys are changed.

The result shows the imported count, missing binding count, and unsupported
key count. Missing and unsupported entries leave existing bindings unchanged.
Duplicate-key conflicts are preserved; Minecraft's normal key-bind screen
shows them. Mouse sensitivity, graphics settings, and other options are not
part of the exported profile.

## Portability

Profiles store binding IDs such as key.forward and named keys such as
key.keyboard.w and key.mouse.left. Numeric key codes are not copied between
versions. This keeps keyboard and mouse bindings portable across the GLFW to
SDL change in Minecraft 26.3.

Vanilla and mod bindings registered in Minecraft's key-bind list are included.
The same binding ID must exist on the target. Install the relevant mod there
to import its keys. Mod-private controls, modifier combinations, and settings
outside Minecraft's KeyMapping system are outside the profile format.

Raw scan-code bindings are skipped when the input backend differs, because
those numbers have different meanings. Named modifier keys, numpad keys,
extra mouse buttons, and unbound keys are supported.

The text format is version-independent, but each Minecraft version needs a
compatible mod build. The two supplied JARs are for 1.21.11 and 26.3; they are
not universal JARs for every historical or future Minecraft release.

## Text format example

```properties
# Keybind Porter - portable Minecraft key bindings
keybindporter.format=1
keybindporter.minecraft=1.21.11
keybindporter.backend=glfw
bind.key.forward=key.keyboard.w
bind.key.attack=key.mouse.left
bind.key.inventory=key.keyboard.e
```

The same file imports into 26.3. Binding IDs with special characters use
standard Java properties escaping; files use UTF-8.

## Build and test

Use Java 25 for the build tool. The 1.21.11 artifact targets Java 21 bytecode;
the 26.3 artifact targets Java 25 bytecode. Gradle 9.6.0 wrapper included.

```sh
./gradlew :mc12111:build :mc263:build
./gradlew :mc12111:bindingSmokeTest :mc263:bindingSmokeTest
./gradlew :mc12111:bindingSmokeTest
```

On Windows replace ./gradlew with gradlew.bat. JARs appear under each module's
build/libs. For 1.21.11 use the remapped release JAR under build/libs, not a dev
JAR. A file ending in -sources.jar is not installed as a mod.

The first smoke-test pair generates profiles from both game versions and
checks forward import; the second 1.21.11 run checks reverse import. Tests
launch Fabric's client class loader before creating a graphics window.

## Validation

- Builds passed for both Minecraft versions using Loom 1.17.21, Gradle 9.6.0,
  Fabric Loader 0.19.5, and Java 25 as the build/test runtime.
- 1.21.11: 51 initial checks, then 72 checks with the 26.3 export available.
- 26.3: 72 checks, including a real 1.21.11 exported text profile.
- Both 1.21.11 -> 26.3 and 26.3 -> 1.21.11 passed for 20 named input tokens:
  letters, space, Shift/Ctrl/Alt, Tab/Escape, function keys, numpad keys, mouse
  left/right/middle/extra buttons, and unbound.
- Text/file round trips, overwrite protection, Unicode binding IDs, malformed
  formats, missing actions, invalid keys, and unsafe cross-backend scan codes
  were checked.
- Required key-bind-screen mixin applied on both versions. Transfer screen
  classes loaded successfully. Test code stays outside the release JARs.

The GUI has compiled and its client mixin has been checked, but clicking the
buttons, opening the OS folder, and the visual layout have not been tested in
an interactive Minecraft window. Test profiles use synthetic action IDs to
check transfer mechanics; actual vanilla/mod entries are collected at runtime
from Minecraft's key-bind list.
