package dev.keybindporter;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
public final class TransferScreen extends TransferScreenBase {
    public TransferScreen(Screen parent, boolean importing) { super(parent, importing); }
    @Override public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        super.render(graphics, mouseX, mouseY, delta);
        graphics.drawCenteredString(font, title, width / 2, 14, 0xFFFFFFFF);
        int span = Math.min(600, width - 32), left = (width - span) / 2;
        graphics.drawString(font, "File name or full path", left, 34, 0xFFAAAAAA);
        if (visibleRows > 0) graphics.drawString(font, "Profiles in keybind-profiles", left, 103, 0xFFAAAAAA);
        var lines = font.split(Component.literal(status), span);
        for (int i = 0; i < Math.min(3, lines.size()); i++)
            graphics.drawString(font, lines.get(i), left, height - 64 + i * 10, statusColor);
    }
}
