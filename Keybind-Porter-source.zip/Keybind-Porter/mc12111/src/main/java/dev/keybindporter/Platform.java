package dev.keybindporter;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
public final class Platform {
    public static final String MINECRAFT = "1.21.11";
    public static final String BACKEND = "glfw";
    public static void openScreen(Screen screen) { Minecraft.getInstance().setScreen(screen); }
    private Platform() {}
}
