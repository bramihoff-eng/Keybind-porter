package dev.keybindporter;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
public final class Platform {
    public static final String MINECRAFT = "26.3";
    public static final String BACKEND = "sdl";
    public static void openScreen(Screen screen) { Minecraft.getInstance().gui.setScreen(screen); }
    private Platform() {}
}
