package dev.keybindporter;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
public final class TransferScreen extends TransferScreenBase {
    public TransferScreen(Screen parent, boolean importing) { super(parent, importing); }
    @Override public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
        graphics.centeredText(font, title, width / 2, 14, 0xFFFFFFFF);
        int span = Math.min(600, width - 32), left = (width - span) / 2;
        graphics.text(font, "File name or full path", left, 34, 0xFFAAAAAA);
        if (visibleRows > 0) graphics.text(font, "Profiles in keybind-profiles", left, 103, 0xFFAAAAAA);
        var lines = font.split(Component.literal(status), span);
        for (int i = 0; i < Math.min(3, lines.size()); i++)
            graphics.text(font, lines.get(i), left, height - 64 + i * 10, statusColor);
    }
}
