package dev.keybindporter;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

/** Version-independent UTF-8 text format. Binding IDs and named key tokens are portable. */
public final class ProfileIO {
    public record Profile(String minecraft, String backend, Map<String, String> bindings) {
        public Profile { bindings = Map.copyOf(bindings); }
    }

    public static Profile read(Path path) throws IOException {
        if (Files.size(path) > 1_048_576) throw new IOException("Profile is larger than 1 MB.");
        return decode(Files.readString(path, StandardCharsets.UTF_8));
    }

    public static Profile decode(String text) throws IOException {
        Properties p = new Properties();
        try { p.load(new StringReader(text.startsWith("\uFEFF") ? text.substring(1) : text)); }
        catch (IllegalArgumentException e) { throw new IOException("The profile contains invalid text escapes.", e); }
        if (!"1".equals(p.getProperty("keybindporter.format")))
            throw new IOException("Not a Keybind Porter v1 profile. Export a .txt file with the mod first.");
        Map<String, String> bindings = new TreeMap<>();
        for (String name : p.stringPropertyNames()) {
            if (name.startsWith("bind.")) {
                String id = name.substring(5);
                String key = p.getProperty(name).trim();
                if (id.isBlank() || key.isBlank()) throw new IOException("A binding ID or key is empty.");
                bindings.put(id, key);
            }
        }
        if (bindings.isEmpty()) throw new IOException("This profile contains no key bindings.");
        if (bindings.size() > 10_000) throw new IOException("Too many bindings in this profile.");
        return new Profile(p.getProperty("keybindporter.minecraft", "unknown"),
                p.getProperty("keybindporter.backend", "unknown"), bindings);
    }

    public static String encode(Profile profile) throws IOException {
        StringBuilder text = new StringBuilder("# Keybind Porter - portable Minecraft key bindings\n");
        text.append("# Move this .txt file to another instance and choose Import keys.\n");
        append(text, "keybindporter.format", "1");
        append(text, "keybindporter.minecraft", profile.minecraft());
        append(text, "keybindporter.backend", profile.backend());
        for (var e : new TreeMap<>(profile.bindings()).entrySet()) append(text, "bind." + e.getKey(), e.getValue());
        return text.toString();
    }

    private static void append(StringBuilder target, String name, String value) throws IOException {
        Properties one = new Properties(); one.setProperty(name, value);
        StringWriter out = new StringWriter(); one.store(out, null);
        for (String line : out.toString().split("\\R")) if (!line.startsWith("#")) target.append(line).append('\n');
    }

    public static void writeNew(Path path, Profile profile) throws IOException {
        Path parent = path.toAbsolutePath().getParent();
        if (parent != null) Files.createDirectories(parent);
        Files.writeString(path, encode(profile), StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
    }

    private ProfileIO() {}
}
