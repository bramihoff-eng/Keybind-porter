package dev.keybindporter.mixin;

import dev.keybindporter.Platform;
import dev.keybindporter.TransferScreen;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Options;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.OptionsSubScreen;
import net.minecraft.client.gui.screens.options.controls.KeyBindsScreen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyBindsScreen.class)
public abstract class KeyBindsScreenMixin extends OptionsSubScreen {
    @Shadow private Button resetButton;
    protected KeyBindsScreenMixin(Screen parent, Options options, Component title) { super(parent, options, title); }

    @Inject(method = "addFooter", at = @At("HEAD"), cancellable = true)
    private void keybindporter$addImportExport(CallbackInfo ci) {
        layout.setFooterHeight(60);
        LinearLayout rows = layout.addToFooter(LinearLayout.vertical().spacing(4));
        LinearLayout transfers = rows.addChild(LinearLayout.horizontal().spacing(8));
        transfers.addChild(Button.builder(Component.literal("Import keys..."), b -> Platform.openScreen(new TransferScreen(this, true))).width(150).build());
        transfers.addChild(Button.builder(Component.literal("Export keys..."), b -> Platform.openScreen(new TransferScreen(this, false))).width(150).build());
        LinearLayout standard = rows.addChild(LinearLayout.horizontal().spacing(8));
        resetButton = Button.builder(Component.translatable("controls.resetAll"), b -> {
            for (KeyMapping mapping : options.keyMappings) mapping.setKey(mapping.getDefaultKey());
            KeyMapping.resetMapping();
            Platform.openScreen(new KeyBindsScreen(lastScreen, options));
        }).width(150).build();
        standard.addChild(resetButton);
        standard.addChild(Button.builder(CommonComponents.GUI_DONE, b -> onClose()).width(150).build());
        ci.cancel();
    }
}
