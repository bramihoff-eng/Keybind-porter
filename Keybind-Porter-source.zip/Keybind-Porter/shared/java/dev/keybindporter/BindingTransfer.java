package dev.keybindporter;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public final class BindingTransfer {
    public record Plan(Map<KeyMapping, InputConstants.Key> changes, int missingBindings, int unsupportedKeys) {
        public Plan { changes = Map.copyOf(changes); }
        public int matched() { return changes.size(); }
    }

    public static ProfileIO.Profile capture(KeyMapping[] mappings) {
        Map<String, String> bindings = new TreeMap<>();
        for (KeyMapping mapping : mappings) bindings.put(mapping.getName(), mapping.saveString());
        return new ProfileIO.Profile(Platform.MINECRAFT, Platform.BACKEND, bindings);
    }

    public static Plan prepare(ProfileIO.Profile profile, KeyMapping[] mappings) {
        Map<String, KeyMapping> available = new LinkedHashMap<>();
        for (KeyMapping mapping : mappings) available.put(mapping.getName(), mapping);
        Map<KeyMapping, InputConstants.Key> changes = new LinkedHashMap<>();
        int missing = 0, unsupported = 0;
        for (var e : profile.bindings().entrySet()) {
            KeyMapping binding = available.get(e.getKey());
            if (binding == null) { missing++; continue; }
            String token = e.getValue();
            // Raw scan codes refer to different things in GLFW and SDL. Never guess their conversion.
            if ((token.startsWith("scancode.") || token.startsWith("key.scancode."))
                    && !Platform.BACKEND.equals(profile.backend())) { unsupported++; continue; }
            try {
                InputConstants.Key key = InputConstants.getKey(token);
                if (key == null || !key.getName().equals(token)) { unsupported++; continue; }
                changes.put(binding, key);
            } catch (RuntimeException invalidKey) { unsupported++; }
        }
        return new Plan(changes, missing, unsupported);
    }

    public static void apply(Plan plan) {
        plan.changes().forEach(KeyMapping::setKey);
        KeyMapping.resetMapping();
    }

    private BindingTransfer() {}
}
