package dev.keybindporter;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;

public abstract class TransferScreenBase extends Screen {
    protected final Screen parent;
    protected final boolean importing;
    protected EditBox pathField;
    protected String status = "";
    protected int statusColor = 0xFFA0A0A0;
    protected int visibleRows;
    private int page;
    private final Path folder = FabricLoader.getInstance().getGameDir().resolve("keybind-profiles");
    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS");

    protected TransferScreenBase(Screen parent, boolean importing) {
        super(Component.literal(importing ? "Import key bindings" : "Export key bindings"));
        this.parent = parent; this.importing = importing;
    }

    private String exportName() { return "keybinds-" + Platform.MINECRAFT + "-" + STAMP.format(LocalDateTime.now()) + ".txt"; }

    @Override
    protected void init() {
        String prior = pathField == null ? (importing ? "" : exportName()) : pathField.getValue();
        int span = Math.min(600, width - 32), left = (width - span) / 2;
        pathField = new EditBox(font, left, 46, span, 20, Component.literal("Profile file path"));
        pathField.setMaxLength(2048); pathField.setValue(prior);
        pathField.setHint(Component.literal(importing ? "Choose a file below or paste its full path" : "File name or full path"));
        addRenderableWidget(pathField);
        addRenderableWidget(Button.builder(Component.literal(importing ? "Import file" : "Export file"), b -> transfer())
                .bounds(width / 2 - 114, 74, 110, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Open folder"), b -> openFolder())
                .bounds(width / 2 + 4, 74, 110, 20).build());
        visibleRows = Math.max(0, Math.min(6, (height - 220) / 24 + 1));
        if (height < 220) visibleRows = 0;
        List<Path> files = profiles();
        int pages = visibleRows == 0 ? 1 : Math.max(1, (files.size() + visibleRows - 1) / visibleRows);
        page = Math.min(page, pages - 1);
        for (int row = 0; row < visibleRows; row++) {
            int index = page * visibleRows + row;
            if (index >= files.size()) break;
            Path file = files.get(index);
            String label = font.plainSubstrByWidth(file.getFileName().toString(), span - 14);
            addRenderableWidget(Button.builder(Component.literal(label), b -> pathField.setValue(file.toAbsolutePath().toString()))
                    .bounds(left, 114 + row * 24, span, 20).build());
        }
        if (visibleRows > 0) {
            int y = 114 + visibleRows * 24;
            Button previous = Button.builder(Component.literal("Previous"), b -> { page--; rebuildWidgets(); }).bounds(width / 2 - 114, y, 72, 20).build();
            previous.active = page > 0; addRenderableWidget(previous);
            addRenderableWidget(Button.builder(Component.literal("Refresh"), b -> rebuildWidgets()).bounds(width / 2 - 36, y, 72, 20).build());
            Button next = Button.builder(Component.literal("Next"), b -> { page++; rebuildWidgets(); }).bounds(width / 2 + 42, y, 72, 20).build();
            next.active = page + 1 < pages; addRenderableWidget(next);
        }
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose()).bounds(width / 2 - 100, height - 28, 200, 20).build());
    }

    private List<Path> profiles() {
        try {
            Files.createDirectories(folder);
            try (var paths = Files.list(folder)) {
                return paths.filter(Files::isRegularFile).filter(p -> p.getFileName().toString().endsWith(".txt"))
                        .sorted(Comparator.comparing((Path p) -> p.getFileName().toString()).reversed()).toList();
            }
        } catch (IOException error) { showError(error); return List.of(); }
    }

    private Path chosenPath() throws IOException {
        String typed = pathField.getValue().trim();
        if (typed.length() >= 2 && typed.startsWith("\"") && typed.endsWith("\"")) typed = typed.substring(1, typed.length() - 1);
        if (typed.isBlank()) throw new IOException("Choose a profile file first.");
        Path path = Path.of(typed);
        if (!path.isAbsolute()) path = folder.resolve(path);
        if (!importing && !path.getFileName().toString().endsWith(".txt")) path = path.resolveSibling(path.getFileName() + ".txt");
        return path.toAbsolutePath().normalize();
    }

    private void transfer() {
        try {
            Path chosen = chosenPath();
            if (importing) {
                var profile = ProfileIO.read(chosen);
                var plan = BindingTransfer.prepare(profile, minecraft.options.keyMappings);
                if (plan.matched() == 0) {
                    status = "No matching keys. Missing: " + plan.missingBindings() + "; unsupported: " + plan.unsupportedKeys();
                    statusColor = 0xFFFFCC66; return;
                }
                Path backup = folder.resolve("before-import-" + STAMP.format(LocalDateTime.now()) + ".txt");
                ProfileIO.writeNew(backup, BindingTransfer.capture(minecraft.options.keyMappings));
                BindingTransfer.apply(plan);
                minecraft.options.save();
                status = "Imported " + plan.matched() + ". Missing: " + plan.missingBindings() + "; unsupported: " + plan.unsupportedKeys() + ". Backup saved.";
            } else {
                var profile = BindingTransfer.capture(minecraft.options.keyMappings);
                ProfileIO.writeNew(chosen, profile);
                status = "Exported " + profile.bindings().size() + " keys to " + chosen.getFileName();
            }
            statusColor = 0xFF77DD99;
            rebuildWidgets();
        } catch (Exception error) { showError(error); }
    }

    private void showError(Exception error) {
        status = error instanceof java.nio.file.FileAlreadyExistsException ? "File already exists. Choose a new name." : error.getMessage();
        if (status == null || status.isBlank()) status = "Could not read or write that file.";
        statusColor = 0xFFFF7777;
    }

    private void openFolder() {
        try {
            Files.createDirectories(folder);
            String os = System.getProperty("os.name").toLowerCase(java.util.Locale.ROOT);
            String command = os.contains("win") ? "explorer.exe" : os.contains("mac") ? "open" : "xdg-open";
            new ProcessBuilder(command, folder.toAbsolutePath().toString()).start();
        } catch (IOException error) { status = folder.toAbsolutePath().toString(); statusColor = 0xFFFFCC66; }
    }

    @Override public void onClose() { Platform.openScreen(parent); }
}
