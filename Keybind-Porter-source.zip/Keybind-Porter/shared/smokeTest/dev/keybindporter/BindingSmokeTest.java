package dev.keybindporter;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;
import net.minecraft.SharedConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.server.Bootstrap;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class BindingSmokeTest implements PreLaunchEntrypoint {
    private int checks;
    private void check(boolean valid, String reason) { if (!valid) throw new AssertionError(reason); checks++; }
    private KeyMapping binding(String id, String token) {
        KeyMapping key = new KeyMapping(id, InputConstants.KEY_W, KeyMapping.Category.MISC);
        key.setKey(InputConstants.getKey(token));
        return key;
    }

    @Override public void onPreLaunch() {
        try {
            SharedConstants.tryDetectVersion(); Bootstrap.bootStrap();
            List<String> tokens = List.of("key.keyboard.w", "key.keyboard.a", "key.keyboard.s", "key.keyboard.d",
                    "key.keyboard.space", "key.keyboard.left.shift", "key.keyboard.left.control", "key.keyboard.left.alt",
                    "key.keyboard.tab", "key.keyboard.escape", "key.keyboard.f5", "key.keyboard.f12",
                    "key.keyboard.keypad.0", "key.keyboard.keypad.enter", "key.mouse.left", "key.mouse.right",
                    "key.mouse.middle", "key.mouse.4", "key.mouse.5", "key.keyboard.unknown");
            KeyMapping[] mappings = new KeyMapping[tokens.size()];
            for (int i = 0; i < mappings.length; i++) {
                mappings[i] = binding("key.test.action" + i, tokens.get(i));
                check(mappings[i].saveString().equals(tokens.get(i)), "Named token changed: " + tokens.get(i));
            }
            var profile = BindingTransfer.capture(mappings);
            var decoded = ProfileIO.decode(ProfileIO.encode(profile));
            check(decoded.bindings().equals(profile.bindings()), "Text profile must round-trip exactly");
            Path folder = Path.of(System.getProperty("keybindporter.fixtures")); Files.createDirectories(folder);
            Path own = folder.resolve("export-" + Platform.MINECRAFT + ".txt"); Files.deleteIfExists(own);
            ProfileIO.writeNew(own, profile);
            check(ProfileIO.read(own).bindings().equals(profile.bindings()), "File round-trip");
            boolean overwriteRejected = false;
            try { ProfileIO.writeNew(own, new ProfileIO.Profile("other", "other", Map.of("key.fake", "key.keyboard.g"))); }
            catch (java.nio.file.FileAlreadyExistsException expected) { overwriteRejected = true; }
            check(overwriteRejected && ProfileIO.read(own).bindings().equals(profile.bindings()), "Existing profiles must not be overwritten");
            for (KeyMapping mapping : mappings) mapping.setKey(InputConstants.getKey("key.keyboard.g"));
            var plan = BindingTransfer.prepare(decoded, mappings);
            check(plan.matched() == mappings.length && plan.missingBindings() == 0 && plan.unsupportedKeys() == 0, "All keys must match");
            check(mappings[0].saveString().equals("key.keyboard.g"), "Planning must not change bindings");
            BindingTransfer.apply(plan);
            for (int i = 0; i < mappings.length; i++) check(mappings[i].saveString().equals(tokens.get(i)), "Imported key mismatch");
            Map<String,String> mixed = new LinkedHashMap<>();
            mixed.put(mappings[0].getName(), "key.keyboard.z");
            mixed.put(mappings[1].getName(), "key.keyboard.not-a-valid-key");
            mixed.put("key.absent.mod", "key.keyboard.p");
            mixed.put(mappings[2].getName(), "scancode.999");
            String otherBackend = Platform.BACKEND.equals("glfw") ? "sdl" : "glfw";
            var partial = BindingTransfer.prepare(new ProfileIO.Profile("other",otherBackend,mixed), mappings);
            check(partial.matched() == 1 && partial.missingBindings() == 1 && partial.unsupportedKeys() == 2, "Unknown actions and unsafe raw scan codes must be skipped");
            BindingTransfer.apply(partial);
            check(mappings[0].saveString().equals("key.keyboard.z"), "Known action should import");
            check(mappings[1].saveString().equals(tokens.get(1)), "Unsupported keys must remain unchanged");
            boolean badFormatRejected = false;
            try { ProfileIO.decode("keybindporter.format=999\nbind.key.forward=key.keyboard.w\n"); }
            catch (java.io.IOException expected) { badFormatRejected = true; }
            check(badFormatRejected, "Newer/invalid profile formats must be rejected");
            var escaped = new ProfileIO.Profile(Platform.MINECRAFT, Platform.BACKEND, Map.of("key.mod.example: spaces=é", "key.keyboard.x"));
            check(ProfileIO.decode(ProfileIO.encode(escaped)).bindings().equals(escaped.bindings()), "Mod IDs with separators and Unicode must round-trip");
            Class<?> screen = Class.forName("net.minecraft.client.gui.screens.options.controls.KeyBindsScreen");
            check(Arrays.stream(screen.getDeclaredMethods()).anyMatch(m -> m.getName().contains("keybindporter$addImportExport")), "Controls buttons mixin must apply");
            Class.forName("dev.keybindporter.TransferScreen");
            Path other = folder.resolve("export-" + (Platform.MINECRAFT.equals("26.3") ? "1.21.11" : "26.3") + ".txt");
            if (Files.exists(other)) {
                var fromOther = ProfileIO.read(other);
                var cross = BindingTransfer.prepare(fromOther, mappings);
                check(cross.matched() == mappings.length && cross.unsupportedKeys() == 0, "Cross-version named keys must all match");
                BindingTransfer.apply(cross);
                for (KeyMapping mapping : mappings) check(mapping.saveString().equals(fromOther.bindings().get(mapping.getName())), "Cross-version assignment mismatch");
                System.out.println("CROSS_VERSION_IMPORT_PASSED: " + fromOther.minecraft() + " -> " + Platform.MINECRAFT);
            }
            System.out.println("KEYBIND_PORTER_TESTS_PASSED: " + checks + " checks on " + Platform.MINECRAFT);
            System.exit(0);
        } catch (Throwable failure) { failure.printStackTrace(); System.exit(1); }
    }
}
